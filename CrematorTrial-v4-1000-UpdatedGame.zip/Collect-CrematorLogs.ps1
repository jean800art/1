param(
    [string]$OutputDirectory = 'D:\SteamLibrary\steamapps\common\Helldivers 2\tools\cremator-mod\build',
    [string]$GameDirectory = 'D:\SteamLibrary\steamapps\common\Helldivers 2'
)
$ErrorActionPreference = 'Stop'
$logDirectory = Join-Path $env:LOCALAPPDATA 'CowboyBingus\Helldivers2\Logs'
$logs = @(Get-ChildItem -LiteralPath $logDirectory -File | Where-Object { $_.Name -match '^(CrematorTrial-v\d+|CrematorCompat-\d+).*\.log$' })
if ($logs.Count -eq 0) { throw 'No CrematorTrial logs exist yet. Install the playable trial and run the game first.' }
$root = [IO.Path]::GetFullPath($OutputDirectory)
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss-fff'
$folder = Join-Path $root ('CrematorTrial-logs-' + $stamp)
New-Item -ItemType Directory -Path $folder | Out-Null
foreach ($log in $logs) { Copy-Item -LiteralPath $log.FullName -Destination (Join-Path $folder $log.Name) }
$exe = Join-Path $GameDirectory 'bin\helldivers2.exe'
$metadata = [ordered]@{
    collectedAt = (Get-Date).ToString('o')
    gameExeSha256 = (Get-FileHash -LiteralPath $exe -Algorithm SHA256).Hash
    logFiles = @($logs | Select-Object Name,Length,LastWriteTime)
    patches = @(Get-ChildItem -LiteralPath (Join-Path $GameDirectory 'data') -File |
        Where-Object { $_.Name -match '^9ba626afa44a3aa3\.patch_\d+$' } |
        Select-Object Name,Length,LastWriteTime)
}
$metadata | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $folder 'metadata.json') -Encoding utf8
$archive = $folder + '.zip'
Compress-Archive -LiteralPath @(Get-ChildItem -LiteralPath $folder -File | Select-Object -ExpandProperty FullName) -DestinationPath $archive
Write-Output ('Collected locally: ' + $archive)
Write-Output 'No files were uploaded. Existing logs and game files were preserved.'
